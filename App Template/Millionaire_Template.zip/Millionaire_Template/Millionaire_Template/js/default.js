﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll());
        }
    };

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. You might use the
        // WinJS.Application.sessionState object, which is automatically
        // saved and restored across suspension. If you need to complete an
        // asynchronous operation before your application is suspended, call
        // args.setPromise().
    };

    app.start();
})();
//6 questions
//need to replace progressbar_X with each successor per correct answer
//questions in an array to just be placed in the top box
//Have the same answers in the same places.



//The Questions:
var qOne = "rain";
var qTwo = "rain";
var qThree = "rain";
var qFour = "rain";
var qFive = "rain";
var qSix = "rain";

var qRay = new Array(qOne, qTwo, qThree, qFour, qFive, qSix);

//The Correct Answers
var aOne = 1;
var aTwo = 2;
var aThree = 3;
var aFour = 4;
var aFive = 1;
var aSix = 2;
var aRay = new Array(aOne, aTwo, aThree, aFour, aFive, aSix);

//Correct answer:
var Fans1a = "rain";
var Fans1b = "rain";
var Fans1c = "rain";
var Fans1d = "rain";

var Fans2a = "rain2";
//Correct answer:
var Fans2b = "rain2";
var Fans2c = "rain2";
var Fans2d = "rain2";

var Fans3a = "rain3";
var Fans3b = "rain3";
//Correct answer:
var Fans3c = "rain3";
var Fans3d = "rain3";

var Fans4a = "rain4";
var Fans4b = "rain4";
var Fans4c = "rain4";
//Correct answer:
var Fans4d = "rain4";

//Correct answer:
var Fans5a = "rain4";
var Fans5b = "rain4";
var Fans5c = "rain4";
var Fans5d = "rain4";

var Fans6a = "rain5";
//Correct answer:
var Fans6b = "rain5";
var Fans6c = "rain5";
var Fans6d = "rain5";

var Fans = new Array(Fans1a, Fans1b, Fans1c, Fans1d, Fans2a, Fans2b, Fans2c, Fans2d, Fans3a, Fans3b, Fans3c, Fans3d, Fans4a, Fans4b, Fans4c, Fans4d, Fans5a, Fans5b, Fans5c, Fans5d, Fans6a, Fans6b, Fans6c, Fans6d);

var Pbar = new Array();
Pbar[0] = new Image();
Pbar[0].src = 'progressBar_Empty.png';
Pbar[1] = new Image();
Pbar[1].src = 'progressBar_one.png';
Pbar[2] = new Image();
Pbar[2].src = 'progressBar_two.png';
Pbar[3] = new Image();
Pbar[3].src = 'progressBar_three.png';
Pbar[4] = new Image();
Pbar[4].src = 'progressBar_four.png';
Pbar[5] = new Image();
Pbar[5].src = 'progressBar_five.png';


function Insert() {
            locaz = document.getElementById('locaz1').innerHTML;
            local = document.getElementById('local1').innerHTML;
            localz = document.getElementById('localz1').innerHTML;
            local = Number(local);
            locaz = Number(locaz);
            localz = Number(localz);

            if (localz == 0) {
                localz = localz + 1;
                document.getElementById('localz1').innerHTML = localz;

                
                document.getElementById('Riddle').innerHTML = aRay[local];

                document.getElementById('One').innerHTML = Fans[local];
                document.getElementById('Two').innerHTML = Fans[local + 1];
                document.getElementById('Three').innerHTML = Fans[local + 2];
                document.getElementById('Four').innerHTML = Fans[local + 3];
                document.getElementById('Fubar').innerHTML = Pbar[locaz];
            }
            else {
                locaz = document.getElementById('locaz1').innerHTML;
                local = document.getElementById('local1').innerHTML;
            }
        }


function finalGuess(num) {
    num = Number(num);
    if (num == aRay[locaz]) {
        this.local = this.local + 4;
        this.locaz = this.locaz + 1;
        document.getElementById('Riddle').innerHTML = aRay[locaz];

        document.getElementById('One').innerHTML = Fans[local];
        document.getElementById('Two').innerHTML = Fans[local + 1];
        document.getElementById('Three').innerHTML = Fans[local + 2];
        document.getElementById('Four').innerHTML = Fans[local + 3];
        
        document.getElementById('Fubar').src = Pbar[locaz].src;
        document.getElementById('locaz1').innerHTML = locaz;
        document.getElementById('local1').innerHTML = local;
        
        
    }
    else {
        document.getElementById('Riddle').innerHTML = aRay[local];

        document.getElementById('One').innerHTML = Fans[local];
        document.getElementById('Two').innerHTML = Fans[local + 1];
        document.getElementById('Three').innerHTML = Fans[local + 2];
        document.getElementById('Four').innerHTML = Fans[local + 3];

        document.getElementById('Fubar').src = Pbar[locaz].src;
        
    }
}